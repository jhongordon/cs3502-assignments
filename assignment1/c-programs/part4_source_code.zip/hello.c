#include <stdio.h>
int main() {
printf("Welcome to OwlTech Industries!\n");
return 0;
}
